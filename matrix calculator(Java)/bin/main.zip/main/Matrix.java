package main;
import java.util.*;


public class Matrix {
	
	//fields:
	private Vector<MathVector> rows;
	private int variables;	//the amount of variables in the mathVectors inside this matrix
	private boolean complex;	//true indicates that the equations are in the complex field
	
	//constructors:
	public Matrix()
	{
		this.rows = new Vector<MathVector>();
	}
	
	public Matrix(int variables, boolean complex,Vector<MathVector> rows) {
		this.rows = rows;
		this.complex = complex;
		this.variables = variables;
	}
	
	public Matrix(int variables, boolean complex){
		this.rows = new Vector<MathVector>();
		this.complex = complex;
		this.variables = variables;
	}
	
	
	// getters and setters:
	
	//returns the equation in the i'th row
	public MathVector getRows(int i) {
		return this.rows.elementAt(i);
	}

	public void setRows(Vector<MathVector> rows) {
		// this function set the rows of the matrix
		this.complex = rows.get(0).getType();
		this.variables = rows.get(0).getN();
		this.rows = rows;
	}
		
	public void add(MathVector v1)
	// this function add a row of scalars to the matrix
	{
		if (this.rows.size() == 0)
		{
			this.variables = v1.getN();
			this.complex = v1.getType();
			this.rows.add(v1);
		}			
		else if (v1.getN() == this.variables & this.complex == v1.getType())
			this.rows.add(v1);
	}
	
	public Vector<MathVector> getRows() {
		return rows;
	}
	
	public boolean getType()
	{
		return this.complex;
	}
	
	public int getVariables()
	{
		return this.variables;
	}
	
	//sets the equation in the i'th row
	public void setRows(MathVector v1, int i) {
		if (i <= this.rows.size() & this.complex == v1.getType())
			this.rows.setElementAt(v1, i);
	}
	
	
	// methods:	
		
	public Matrix add(Matrix mat)
	//returns a matrix which is the sum of mat+this
	{
		Matrix result = new Matrix(this.variables,this.complex) ;
		if (mat.rows.size() == this.rows.size() &
				this.variables == mat.getVariables() &
				this.complex == mat.getType())
		{
			for (int i=0 ; i<this.rows.size() ; i++)
			{
				result.rows.add(this.rows.elementAt(i).add(mat.rows.elementAt(i)));
			}
		}
		else 
			return null;  
		result.minimize();
		return result;
	}

	public Matrix mul(Matrix mat)
	{		
		if ( mat.rows.size() != this.rows.firstElement().getN() |
				this.complex != mat.getType())
		{
			return null;				
		}
		Matrix result = new Matrix(mat.getVariables(), this.complex);
		Matrix otherMat = mat.transpose();
		for (int i = 0; i < this.rows.size(); i++)
		{
			LinkedList<Scalar> currentVectorValues = new LinkedList<Scalar>();
			for(int j = 0; j < otherMat.rows.size(); j++)
			{
				currentVectorValues.add(this.rows.elementAt(i).mul(otherMat.rows.elementAt(j)));
			}
			MathVector newRowforResult = new MathVector(currentVectorValues.size(),  this.complex, currentVectorValues);
			result.add(newRowforResult);
		}
		result.minimize();
		return result;
	}
	
	public void rowSwitching(int i, int j)
	// the function switch rows i and j
	{
		MathVector temp = new MathVector(this.rows.firstElement().getN());
		temp = this.rows.elementAt(i);
		this.rows.set(i, this.rows.elementAt(j));
		this.rows.set(j, temp);
	}
	
	public Matrix transpose()
	{
		Matrix result = new Matrix(this.rows.size(), this.complex);
		for (int i = 0; i < this.variables; i++)
		{
			LinkedList<Scalar> nextRowValues = new LinkedList<Scalar>();
			for(int j = 0; j < this.rows.size(); j++)
			{
				nextRowValues.add(this.rows.get(j).getValues().get(i));
			}
			MathVector nextRow = new MathVector(this.rows.size(), this.complex, nextRowValues);
			result.add(nextRow);	
		}
		result.minimize();
		return result;
	}
	
	public Matrix Solve()
	// Gal -this isn't working the line below.
	{
		if (this.variables < this.rows.size())
		{
			System.out.println("this equasion is unsolvable:" + System.getProperty("line.separator") + System.getProperty("line.separator"));
			this.toString();
			return null;
		}
		else
		{
				return solveMat();
		}
	}
	


	private Matrix solveMat() {
		Matrix result = this.copyMat();
		if (result!=null ) 
		{
			// set the first row and scalar to begin :
			MathVector firstRow = new MathVector(result.getVariables(), result.complex, result.getRows(1).getValues());
			Scalar firstScalar = firstRow.getValues().get(0);
			Rational zero = new Rational(0, 1);
			// set the indexes of the matrix:
			int firstColIndex = 0;
			int firstRowIndex = 0;
			
			//check that the matrix begin with scalar different then zero
			while (firstScalar.equalzero(zero))
			{	
				if (firstRowIndex!= result.getVariables()-2)
				{
					result.rowSwitching(0, firstRowIndex+1);
					firstRow = new MathVector(result.getVariables(), result.complex, result.getRows(firstRowIndex+1).getValues());
					firstScalar = firstRow.getValues().get(0);
					firstRowIndex++;
				}
				else
				{
					if (firstColIndex!=result.getRows().capacity()-1)
					{
						firstColIndex++;
						firstRowIndex=0;
						firstRow = new MathVector(result.getVariables(), result.complex, result.getRows(firstRowIndex+1).getValues());
						firstScalar = firstRow.getValues().get(firstColIndex);
					}
					else { System.out.println("there is no solution"); return result; }
				}
			}
			// now the first scalar is different than 0
			MathVector VectoMultipy = new MathVector (result.rows.size(),this.complex);
			Rational neg = new Rational(-1,1);
			// the loops below make zero's from the diagonal down
			for ( int j = firstColIndex ; j< result.rows.size()-1 && result.thereIsResult() ; j++)
			{
				
				Scalar toMultiply1 = firstScalar;
				for ( int i = 1+j ; i< result.variables-1 && result.thereIsResult() ; i++)
				{
					//initialize first row:
					//
					Scalar toMultiply2 = result.getRows(i+1).getValues().get(j);
					MathVector copyOfFirstRow = firstRow.mulByScalar(toMultiply2);
					
					VectoMultipy = result.getRows(i+1);
					VectoMultipy = VectoMultipy.mulByScalar(toMultiply1);
					
					// substract the vector in the line below from the top line Vector.
					copyOfFirstRow = copyOfFirstRow.mulByScalar(neg);
					MathVector newVec= new MathVector(result.getRows().capacity(), result.complex);
					newVec = VectoMultipy.add(copyOfFirstRow);
					result.setRows(newVec, i+1);
					
				} if (!thereIsResult()){ System.out.println("there is no solution"); return result; }
				if (this.nextRow(firstRow)!=null)
				{
				firstRow=this.nextRow(firstRow);
				firstScalar = nextFirstScalar(firstColIndex, firstRowIndex, firstScalar);
				}
				
			} if (!thereIsResult()) { System.out.println("there is no solution"); return result; }
		
			// now from the diagonal down there are only zero's
			// solving: 
			
			for (int m = result.variables-1 ; m>=1 ;m--)
			// this loop makes the diagonal line to be "1".
			{
				MathVector lastRow = result.rows.get(m-1);
				Scalar toMultiplyTheRow = lastRow.getValues().get(m-1);
				toMultiplyTheRow = toMultiplyTheRow.inv();
				lastRow=lastRow.mulByScalar(toMultiplyTheRow);
				result.setRows(lastRow, m);
				lastRow= result.prevRow(lastRow);
			}
			
			// now the matrix is "medoreget" and the diagonal is 1
			MathVector lastRow = result.rows.lastElement();
			MathVector beforeLastRow =  result.prevRow(lastRow);
			int howManyRows = result.variables-1;
			int indexScalarToSubstract = result.variables-1;
			int j=0;
			Scalar sca = beforeLastRow.getValues().get(indexScalarToSubstract-1);
			while (howManyRows>=1)
			{
				
				MathVector copyOfBeforeLastRow=beforeLastRow;
				
				while (!sca.equalzero(zero)) //  && beforeLastRow!=result.rows.get(1)) //)
				{
					// substract the vector from the vector below
					MathVector  lastRowInNegative = lastRow.mulByScalar(sca);
					lastRowInNegative = lastRowInNegative.mulByScalar(neg);
					copyOfBeforeLastRow = copyOfBeforeLastRow.add(lastRowInNegative);
					result.setRows(copyOfBeforeLastRow, howManyRows-1);
					//  check the scalar to substract again
					sca = copyOfBeforeLastRow.getValues().get(indexScalarToSubstract-1);
					
				}
				howManyRows--;
				if (result.prevRow(copyOfBeforeLastRow)!=null) // if the before last row is the first
				{
					beforeLastRow =  result.prevRow(copyOfBeforeLastRow);
				}
				else 
				{
					j++;
					howManyRows = result.variables-1-j;;
					lastRow = result.prevRow(lastRow);
					if (result.prevRow(lastRow)!=null)
					{
						beforeLastRow =  result.prevRow(lastRow);
						indexScalarToSubstract--;
						sca = beforeLastRow.getValues().get(indexScalarToSubstract-1);	
						
					}
					else 
					{
						// need to get out of the loop
						howManyRows=0;
					}
				}
				sca = beforeLastRow.getValues().get(indexScalarToSubstract-1);
			}
			
//			for (int m = result.rows.size()-1 ; m>=0 ;m--)
//			//columns
//			{	
//
//				 lastRow = result.rows.lastElement();
//				 beforeLastRow =  result.prevRow(lastRow);
//				for (int n=m+1; n>1 ; n--)
//				//rows
//				{
//					// the scalars to multiply the rows
//					Scalar toMultiplyTheRowBeforeTheLast = lastRow.getValues().get(m);
//					Scalar toMultiplyTheLastRow = beforeLastRow.getValues().get(m);
//					
//					// multiply the vectors in the last row and before the last row
//					MathVector copyOfLastRow=lastRow.mulByScalar(toMultiplyTheLastRow);
//					MathVector copyOfBeforeLastRow=beforeLastRow.mulByScalar(toMultiplyTheRowBeforeTheLast);
//			
//					// substract the vector in the last row from the row in the row before the last
//					copyOfBeforeLastRow = copyOfBeforeLastRow.mulByScalar(neg);
//					
//					// newVec is the new vector to be added the matrix in the "before last row" place 
//					MathVector newVec= new MathVector(result.getRows().capacity(), result.complex);
//					newVec = copyOfLastRow.add(copyOfBeforeLastRow);
//					 
//					// need to replace "newVec" with the "beforeLastRow" vector
//					int indexOfBeforeLastRow = m;
//					result.setRows(newVec, indexOfBeforeLastRow);
//					beforeLastRow =  result.prevRow(newVec);
//				}
//				lastRow=this.prevRow(lastRow);
//			}
	}
	return result;
	}
	
	
public Scalar nextFirstScalar (int col , int row , Scalar first) 
{
	// the function returns the next scalar after the "first Scalar"
	if (col > this.getRows().size()- 1) 
		return first;
	Scalar result = this.getRows(row+2).getValues().get(col+1);
	return result;
	
}

private Matrix rankingMat(Matrix result) {
		MathVector futureRankedRow, currentResettingVector;
		Scalar diagonalLeader;
		Scalar negativeScalar = new Rational(-1,1);
		for (int columnPointer = 0; columnPointer < variables - 2; columnPointer++)
		{
			if (result.getType())
			{
				diagonalLeader = new Complex((Complex)result.rows.get(columnPointer).getValues().get(columnPointer));//diagonal leader = a_ii
			}
			else 
			{
				diagonalLeader = new Rational((Rational)result.rows.get(columnPointer).getValues().get(columnPointer));//diagonal leader = a_ii
			}
			
			for (int rowPointer = columnPointer; rowPointer < result.rows.size() - 1; rowPointer++)
			{
				futureRankedRow = result.getRows(rowPointer + 1);
				currentResettingVector = new MathVector(result.getRows(columnPointer));
				currentResettingVector = currentResettingVector.mulByScalar(diagonalLeader.inv());//resetting vector's leader becomes 1
				currentResettingVector = currentResettingVector.mulByScalar(futureRankedRow.getValues().get(columnPointer));//resetting vector's leader becomes equal to the reseted scalar
				futureRankedRow = futureRankedRow.add(currentResettingVector.mulByScalar(negativeScalar));
				result.setRows(futureRankedRow, rowPointer + 1); 
			}
		}
		return result;
	}

public boolean thereIsResult ()
//the function checks that there is no row of zero's
{
	Rational zero = new Rational(0, 1);	
	if (this.complex)
	{
		for (int i= 0 ; i <this.variables-1 ; i++)
		{
			if ((this.getRows().elementAt(i).sum()).equalzero(zero))
			{
				return false;
			}
		}
	}
	else if (!this.complex)
	{
		for (int i= 0 ; i <this.variables-1 ; i++)
		{
			if (((Rational)this.getRows().elementAt(i).sum()).equalzero(zero))
			{
				return false;
			}
		}
		
	}
	return true;
}
	
	public String toString()
	{
		String result = "";
		for (MathVector eq : this.rows)
		{
			result += eq.toString() + System.getProperty("line.separator");
		}
		return result;
	}
	
	private boolean checkRanked(int iValue){
		MathVector checkedVector = this.rows.elementAt(iValue);
		LinkedList<Scalar> variables = checkedVector.getValues();
		Scalar pointer;
		pointer = variables.getFirst();
		for (int counter = 0; counter < variables.size(); counter++)
		{
			if (counter == iValue)
				if (pointer instanceof Rational)
					if (((Rational)pointer).getValue() != 1.0 )
						{return false;}
					else{}
				else if (((Complex)pointer).getA().getValue() != 1.0 | ((Complex)pointer).getB().getValue() != 0)
					return false;
			if (pointer instanceof Rational)
				if (((Rational)pointer).getValue() != 0 )
					{return false;}
				else{}
			else if (((Complex)pointer).getA().getValue() != 0 | ((Complex)pointer).getB().getValue() != 0)
				return false;
					
		}
		return true;
	}
	
	public Matrix copyMat()
	// the function returns the same "this" matrix
	{
		Matrix ret= new Matrix( this.getVariables(), this.getType());
		ret.setRows(this.getRows());
		return ret;
	}
	
	private void minimize() 
	{
		for (MathVector v1: rows)
		{
			for (Scalar s1: v1.getValues())
			{
				s1.minimize();
			}
		}
	}
	
	public MathVector nextRow (MathVector prev)
	// the function returns the row next to the given row, null if this is the last row
	{
		if (this.rows.indexOf(prev)==this.rows.size()) return null;
		int rowOfPrev = this.rows.indexOf(prev)+1;
		if (rowOfPrev==this.rows.size()-1) return null;
		return this.rows.elementAt(rowOfPrev+1);
	}

	public MathVector prevRow (MathVector next)
	//the function returns the row prev to the given row, null if this is the first row
	{
		boolean indexOfNext =this.rows.contains(next);
		if (!indexOfNext)
		{
			return null;
		}
		int indexOfNextint = this.rows.indexOf(next);
		if (indexOfNextint == 0)
			{
			return null; // first row
			}
		
		int rowOfnext = this.rows.indexOf(next)-1;
		return this.rows.elementAt(rowOfnext);
	}

	
}
