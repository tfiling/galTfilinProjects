package main;
import java.util.LinkedList;
import java.util.Vector;

public class mainForTesting {

	public static void main (String[] args)
	{
		Matrix mat = new Matrix(3, true);
		LinkedList<Scalar> values4 = new LinkedList<Scalar>(); 
		Rational one= new Rational(1, 1);
		Rational two= new Rational(2, 1);
		Rational three= new Rational(3, 1);
		Rational zero= new Rational(0, 1);
		Rational half= new Rational(1, 2);
		
		Complex com1 = new Complex(one, zero);
		Complex com4 = new Complex((Rational) one.neg(), zero);
		Complex com2 = new Complex(zero,zero);
		Complex com3 = new Complex(zero, one);
		Complex com5 = new Complex(two, zero);
		Complex com6 = new Complex((Rational)two.neg(),(Rational)two.neg() );
		Complex com7 = new Complex(two, one);
		
		
		values4.add(0, com1);
		values4.add(1, com4);
		values4.add(2, com3);
		values4.add(3, com1);
		
		MathVector rows = new MathVector(4, true, values4);
		mat.add(rows);
		LinkedList<Scalar> values3 = new LinkedList<Scalar>(); 
		values3.add(0, com2);
		values3.add(1, com5);
		values3.add(2, com6);
		values3.add(3, com3);
		
		MathVector rows2 = new MathVector(4, true, values3);
		mat.add(rows2);
		LinkedList<Scalar> values2 = new LinkedList<Scalar>();
		values2.add(0, com2);
		values2.add(1, com2);
		values2.add(2, com7);
		values2.add(3, com2);
		
		MathVector rows1 = new MathVector(4, true, values2);
		
		mat.add(rows1);
		
		
		System.out.println();
		
		System.out.print(mat.toString());
		
		mat=mat.Solve();
		
		System.out.print(mat.toString());
		
		
		
		
		
		
		
		
		
		
		
		
		int n = 3;
		MathVector newEQ = new MathVector(n);
		LinkedList<Scalar> values = new LinkedList<Scalar>(); 
		Matrix newMat = new Matrix();
		for (int i = 0; i < n; i++)
		{	
			for (int j = 0; j < n; j++)
			{
				Rational newNum = new Rational();
				newNum.setA(1);
				newNum.setB(1);
				values.add(newNum);
				System.out.print(newNum.toString());
				System.out.println();
			}
			newEQ.setValues(values);
			System.out.print(newEQ.toString());
			System.out.println();
			newMat.add(newEQ);
		}
		System.out.println();
		System.out.print(newMat.toString());
		System.out.println();
		System.out.println();

		newMat = newMat.Solve();
		System.out.print(newMat.toString());
		
		newMat = newMat.add(newMat);

		System.out.print(newMat.toString());
		System.out.println();
		System.out.println();

		newMat = newMat.add(newMat);
		System.out.print(newMat.toString());
		System.out.println();
		System.out.println();
	
		int m = 4;
		MathVector newEQ2 = new MathVector(m);
		 values2 = new LinkedList<Scalar>(); 
		Matrix newMat2 = new Matrix(4, false);
		for (int i = 0; i < m; i++)
		{	
			for (int j = 0; j < m; j++)
			{
				Rational newNum2 = new Rational();
				newNum2.setA(j);
				newNum2.setB(i+1);
				values2.add(newNum2);
				System.out.print(newNum2.toString());
				System.out.println();
			}
			newEQ2.setValues(values2);
			System.out.print(newEQ2.toString());
			System.out.println();
			newMat2.add(newEQ2);
			newEQ2 = new MathVector(m);
			 values2 = new LinkedList<Scalar>();
		}
		
		System.out.println();
		System.out.println();
		System.out.print(newMat2.toString());
		newMat2=newMat2.add(newMat2);
		System.out.println();
		System.out.print(newMat2.toString());
		newMat2=newMat2.Solve();
		System.out.println();
		System.out.print(newMat2.toString());
		
		
		
		newMat2 = newMat2.mul(newMat2);
		System.out.print(newMat2.toString());
		System.out.println();
		System.out.println();
		
		newMat = newMat.add(newMat);
		System.out.print(newMat.toString());
		System.out.println();
		System.out.println();
		
		newMat = newMat.mul(newMat);
		System.out.print(newMat.toString());
		System.out.println();
		System.out.println();
		
		newMat = newMat.add(newMat);

		System.out.print(newMat.toString());
		System.out.println();
		System.out.println();
		
		newMat = newMat.mul(newMat);
		System.out.print(newMat.toString());

		System.out.println();
		System.out.println();
		newMat = newMat.add(newMat);

		System.out.print(newMat.toString());
		System.out.println();
		System.out.println();
		Rational newNum = new Rational();
		Complex complexNum = new Complex();
		complexNum.setA(newNum);
		complexNum.setB(newNum);

		System.out.print(complexNum.toString());
	
	}
}
